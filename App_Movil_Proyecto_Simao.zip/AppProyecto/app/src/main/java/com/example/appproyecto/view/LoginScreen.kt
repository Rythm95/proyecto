package com.example.appproyecto.view

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.appproyecto.viewmodel.AuthViewModel

@Composable
fun LoginScreen(onLoginCorrecto: (String) -> Unit, vm: AuthViewModel = viewModel()) {

    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }

    val loginState by vm.loginState.collectAsState()
    val error by vm.error.collectAsState()

    LaunchedEffect(loginState) {
        loginState?.let { uid ->
            onLoginCorrecto(uid)
        }
    }

    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Card(
            modifier = Modifier
                .padding(24.dp)
                .fillMaxWidth(),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {

            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {

                Text(
                    text = "Iniciar sesión", style = MaterialTheme.typography.titleLarge
                )

                TextField(
                    value = email, onValueChange = {
                        email = it
                        vm.limpiarError()
                    }, label = { Text("Email") }, modifier = Modifier.fillMaxWidth()
                )

                TextField(
                    value = password,
                    onValueChange = {
                        password = it
                        vm.limpiarError()
                    },
                    visualTransformation = PasswordVisualTransformation(),
                    label = { Text("Contraseña") },
                    modifier = Modifier.fillMaxWidth()
                )

                Button(
                    modifier = Modifier.fillMaxWidth(), onClick = {
                        vm.login(email, password)
                    }) {
                    Text("Login")
                }

                if (error != null) {
                    Text(
                        text = error ?: "", color = MaterialTheme.colorScheme.error
                    )
                }
            }
        }
    }
}