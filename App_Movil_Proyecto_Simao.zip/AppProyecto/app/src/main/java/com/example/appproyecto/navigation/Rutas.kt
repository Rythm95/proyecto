package com.example.appproyecto.navigation

sealed class Rutas(val ruta: String) {
    object Login : Rutas("login")

    object Faltas : Rutas("faltas/{alumnoId}") {
        fun createRoute(alumnoId: String) = "faltas/$alumnoId"
    }
}