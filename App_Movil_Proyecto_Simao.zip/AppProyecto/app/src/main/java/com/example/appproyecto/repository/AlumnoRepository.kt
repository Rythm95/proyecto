package com.example.appproyecto.repository

import com.example.appproyecto.model.Alumno
import com.google.firebase.firestore.FirebaseFirestore

class AlumnoRepository {
    private val db = FirebaseFirestore.getInstance()

    fun getAlumno(uid: String, onResult: (Alumno?) -> Unit) {
        db.collection("alumnos")
            .document(uid)
            .get()
            .addOnSuccessListener { doc ->

                if (doc.exists()) {

                    val alumno = Alumno(
                        nombre = doc.getString("nombre") ?: ""
                    )
                    onResult(alumno)

                } else {
                    onResult(null)
                }
            }
            .addOnFailureListener {
                onResult(null)
            }
    }
}