package com.example.appproyecto.viewmodel

import androidx.lifecycle.ViewModel
import com.example.appproyecto.repository.AuthRepository
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class AuthViewModel : ViewModel() {

    private val repository = AuthRepository()

    private val _loginState = MutableStateFlow<String?>(null)
    val loginState: StateFlow<String?> = _loginState

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error

    fun login(email: String, password: String) {
        if (email.isBlank() || password.isBlank()) {
            _error.value = "Email y contraseña no pueden estar vacíos"
            return
        }

        repository.login(email, password) { uid ->

            if (uid != null) {
                _loginState.value = uid
                _error.value = null
            } else {
                _loginState.value = null
                _error.value = "Usuario o contraseña incorrectos"
            }
        }
    }

    fun logout() {
        FirebaseAuth.getInstance().signOut()
    }

    fun limpiarError() {
        _error.value = null
    }
}