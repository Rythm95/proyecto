package com.example.appproyecto.view

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.appproyecto.viewmodel.AlumnoViewModel
import com.example.appproyecto.viewmodel.AuthViewModel
import com.example.appproyecto.viewmodel.FaltaViewModel
import java.text.SimpleDateFormat
import java.util.Locale

@Composable
fun FaltasScreen(
    alumnoId: String,
    onLogout: () -> Unit,
    faltaVm: FaltaViewModel = viewModel(),
    authVm: AuthViewModel = viewModel(),
    alumVm: AlumnoViewModel = viewModel()
) {

    val context = LocalContext.current

    val alumno by alumVm.alumno.collectAsState()
    val faltas by faltaVm.faltas.collectAsState()
    val seleccionada by faltaVm.faltaSeleccionada.collectAsState()

    var textoJustificante by remember { mutableStateOf("") }

    LaunchedEffect(alumnoId) {
        alumVm.cargarAlumno(alumnoId)
        faltaVm.cargarFaltas(alumnoId)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {

        Row(
            modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically
        ) {

            Text(
                text = "Bienvenido, ${alumno?.nombre ?: ""}",
                style = MaterialTheme.typography.titleLarge
            )

            Button(onClick = {
                authVm.logout()
                onLogout()
            }) {
                Text("Cerrar Sesión")
            }
        }

        HorizontalDivider()

        Text("Tus faltas:")

        LazyColumn(
            modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {

            items(faltas) { falta ->

                val fechaForm = falta.fecha?.toDate()?.let {
                    SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(it)
                } ?: ""

                Card(
                    modifier = Modifier.fillMaxWidth(), onClick = {
                        faltaVm.seleccionarFalta(falta)
                    }) {

                    Column(modifier = Modifier.padding(12.dp)) {

                        Text("Fecha: $fechaForm")

                        Text(
                            text = if (falta.justificada) "Justificada"
                            else "Sin justificar"
                        )
                    }
                }
            }
        }

        seleccionada?.let { falta ->
            HorizontalDivider()

            val fechaForm = falta.fecha?.toDate()?.let {
                SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(it)
            } ?: ""

            Text("Justificar falta del $fechaForm")

            if (falta.justificada) {

                Text(
                    text = "Esta falta ya está justificada",
                    color = MaterialTheme.colorScheme.primary
                )

            } else {

                OutlinedTextField(
                    value = textoJustificante,
                    onValueChange = { textoJustificante = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Justificante") })

                Button(
                    modifier = Modifier.fillMaxWidth(), onClick = {
                        faltaVm.justificarFalta(falta.id, textoJustificante)
                        faltaVm.cargarFaltas(alumnoId)
                        textoJustificante = ""
                    }) {
                    Text("Justificar falta")
                }
            }
        }
    }
}