package com.example.appproyecto.navigation

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.appproyecto.view.FaltasScreen
import com.example.appproyecto.view.LoginScreen

@Composable
fun AppNavigation(modifier: Modifier = Modifier) {
    val navController = rememberNavController()

    NavHost(
        navController = navController, startDestination = Rutas.Login.ruta, modifier = modifier
    ) {
        composable(Rutas.Login.ruta) {
            LoginScreen(
                onLoginCorrecto = { alumnoId ->

                    navController.navigate(
                        Rutas.Faltas.createRoute(alumnoId)
                    ) {
                        popUpTo(Rutas.Login.ruta) { inclusive = true }
                    }
                })
        }

        composable(
            Rutas.Faltas.ruta, listOf(navArgument("alumnoId") { type = NavType.StringType })
        ) { backStackEntry ->

            val alumnoId = backStackEntry.arguments?.getString("alumnoId") ?: ""

           FaltasScreen(
               alumnoId = alumnoId,
               onLogout = {
                   navController.navigate(Rutas.Login.ruta){
                       popUpTo(Rutas.Faltas.ruta) { inclusive = true }
                   }
               }
            )

        }
    }
}