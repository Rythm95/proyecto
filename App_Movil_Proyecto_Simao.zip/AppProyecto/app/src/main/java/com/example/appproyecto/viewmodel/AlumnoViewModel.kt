package com.example.appproyecto.viewmodel

import androidx.lifecycle.ViewModel
import com.example.appproyecto.model.Alumno
import com.example.appproyecto.repository.AlumnoRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class AlumnoViewModel : ViewModel() {
    private val repository = AlumnoRepository()
    private val _alumno = MutableStateFlow<Alumno?>(null)
    val alumno: StateFlow<Alumno?> = _alumno

    fun cargarAlumno(uid: String) {

        repository.getAlumno(uid) { resultado ->
            _alumno.value = resultado
        }
    }
}