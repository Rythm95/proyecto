package com.example.appproyecto.model

import com.google.firebase.Timestamp

data class Falta(
    val id: String = "",
    val fecha: Timestamp? = null,
    val justificada: Boolean = false,
    val justificante: String = "",
    val alumnoId: String = ""
)