package com.example.appproyecto.repository

import com.google.firebase.auth.FirebaseAuth

class AuthRepository {
    private val auth = FirebaseAuth.getInstance()

    fun login(email: String, password: String, onResult: (String?) -> Unit) {
        auth
            .signInWithEmailAndPassword(email, password)
            .addOnSuccessListener {

                onResult(it.user?.uid)
            }
            .addOnFailureListener {
                onResult(null)
            }
    }

    fun currentUser() = auth.currentUser
}