package com.example.appproyecto.model

data class Alumno(
    val nombre: String,
)