package com.example.appproyecto.repository

import com.example.appproyecto.model.Falta
import com.google.firebase.firestore.FirebaseFirestore

class FaltaRepository {
    private val db = FirebaseFirestore.getInstance()

    fun justificarFalta(faltaId: String, justificante: String, onResult: (Boolean) -> Unit)
    {
        db.collection("faltas")
            .document(faltaId)
            .update(
                mapOf(
                    "justificada" to true,
                    "justificante" to justificante
                )
            )
            .addOnSuccessListener {
                onResult(true)
            }
            .addOnFailureListener {
                onResult(false)
            }
    }

    fun obtenerFaltasAlumno(alumnoId: String, onResult: (List<Falta>) -> Unit)
    {
        db.collection("faltas")
            .whereEqualTo("alumnoId", alumnoId)
            .get()
            .addOnSuccessListener { snapshot ->
                val faltas = snapshot.documents.mapNotNull { doc ->
                    doc.toObject(Falta::class.java)?.copy(
                        id = doc.id
                    )
                }
                onResult(faltas)
            }
            .addOnFailureListener {
                onResult(emptyList())
            }
    }
}