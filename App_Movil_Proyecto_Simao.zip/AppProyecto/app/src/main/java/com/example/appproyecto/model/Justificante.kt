package com.example.appproyecto.model

data class Justificante(
    val id: String = "",
    val texto: String = "",
    val faltaId: String = ""
)