package com.example.appproyecto.viewmodel

import androidx.lifecycle.ViewModel
import com.example.appproyecto.model.Falta
import com.example.appproyecto.repository.FaltaRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class FaltaViewModel : ViewModel() {
    private val repository = FaltaRepository()
    private val _url = MutableStateFlow("")

    private val _faltas = MutableStateFlow<List<Falta>>(emptyList())
    val faltas: StateFlow<List<Falta>> = _faltas

    private val _faltaSeleccionada = MutableStateFlow<Falta?>(null)
    val faltaSeleccionada: StateFlow<Falta?> = _faltaSeleccionada

    private val _alumnoNombre = MutableStateFlow("")
    val alumnoNombre: StateFlow<String> = _alumnoNombre

    private val _resultadoJustificacion = MutableStateFlow<Boolean?>(null)
    val resultadoJustificacion: StateFlow<Boolean?> = _resultadoJustificacion

    fun cargarFaltas(alumnoId: String) {
        repository.obtenerFaltasAlumno(alumnoId) { lista ->
            _faltas.value = lista
        }
    }

    fun seleccionarFalta(falta: Falta) {
        _faltaSeleccionada.value = falta
    }

    fun justificarFalta(
        faltaId: String,
        justificante: String
    ) {
        repository.justificarFalta(
            faltaId = faltaId,
            justificante = justificante
        ) { success ->

            _resultadoJustificacion.value = success
        }
    }

    fun limpiarResultado() {
        _resultadoJustificacion.value = null
    }
}